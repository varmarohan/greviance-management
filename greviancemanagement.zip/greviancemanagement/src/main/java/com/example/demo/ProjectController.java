package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ProjectController {
	
	@Autowired
	Dao dao;
	
	@GetMapping("/welcome")
	public String fun1() {
		return "welcome.jsp";
	}
	
	
	
	@GetMapping("/register")
	public String fun2() {
		return "register.jsp";
	}
	
	@PostMapping("/save")
	public String fun3(@ModelAttribute User user) {
		User u = new User();
		/*u.setName("");
		u.setDept("");
		u.setPassword("");*/
		dao.insert(user);
		//dao.insert(u);
		return "redirect:/user";
	}
	
	@GetMapping("/user")
	public String fun4() {
		return "user.jsp";
	}

}
